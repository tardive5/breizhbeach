## USER INTERFACE

# The Shiny Application is a map to display beaches located in Britanny, the western part of France
# Source is an opendata set is on http://www.data-tourisme-bretagne.com/web/guest/data

require(shiny)
suppressPackageStartupMessages(library(googleVis))



shinyUI(pageWithSidebar(
  
  headerPanel("Beaches of Brittany,France"),
  
  sidebarPanel(
    
    h5('This apps shows, on a Google map, beaches located in Britanny, at the western part of France.'),
    h5('Beaches are shared between 4 areas with invented names that give you an orientation idea'),
    checkboxGroupInput("iarea", "Choose areas:",
                       c("South Coast" = "6",
                         "In front of Canada" = "9",
                         "In front of Jersey" = "5",
                         "The most beautiful" = "2"),
                       selected=c("2")),
    h5('To make the map readable, please choose a max number of beaches to be displayed'),
    sliderInput('inb', 'Max number of beaches to show',value = 10, min = 1, max = 341, step = 1,)

  ),
  
  mainPanel(
    h3('You did the good choice'),
    h4('Max number of beaches'),
    verbatimTextOutput("onb"),
    
    h4('Average air temperature of sampled beaches (°C)'),
    verbatimTextOutput("otemp"),
    
    htmlOutput("omap"),
    h5('Remark: Sampling can reach twice the same beach so, the total number of beaches displayed on the map can be lower.')
    
  )
))