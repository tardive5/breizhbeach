## SHINY SERVER

# The Shiny Application is a map to display beaches located in Britanny, the western part of France
# Source is an opendata set is on http://www.data-tourisme-bretagne.com/web/guest/data


require(shiny)
# project directory
setwd("../data")

#setwd("/home/tardive5/Documents/TwiProject/code/myproject")
suppressPackageStartupMessages(require(googleVis))


# project directory
#setwd("C:/Users/tardive5/Documents/myproject")

# dataset is Western France beaches information
beaches <- read.csv("PlagesdeBretagne.csv", sep=",")

# add a column to have the latlong format of googlevis
COORD <- c()
for (l in 1:nrow(beaches))
{
  COORD[l] <- paste(beaches[l,10],beaches[l,11], sep=":")
}
beaches <- cbind(beaches, COORD)

# add the air temperature
temp <- read.csv("temp.csv", sep=",")
beaches <- cbind(beaches, temp)


# SHINY SERVER
shinyServer(

  function(input, output) {

    # Max number of beaches to show on the map
    output$onb <- renderPrint({input$inb})

    samp <- reactive({

      # Select only the beaches in the checked areas
      sel <- data.frame()
      for (l in 1:nrow(beaches))
      {
        # Each area is distinguished by the second character of CODEPOSTAL, in the 7th column
        ch <- substr(beaches[l,7],2,2)

        if (any(grep(ch, input$iarea)))
        {
          sel <- rbind(sel, beaches[l,])
        }
      }

      # Sample the selected beaches for the map
      if (nrow(sel) != 0)
      {
        # Choose ramdomly unique samples of beaches
        vec <- unique(sample(c(1:nrow(sel)),input$inb,replace=TRUE))
        samp <- sel[vec,]
      }
      return (samp)

    })

      output$omap <- renderGvis({
        s <- samp()
        if (nrow(s) != 0)
        {

        # display beaches latitude/longitude on Google map; Tip indicates the town name
        gvisMap(samp(), "COORD", "COMMUNE",
              options=list(showTip=TRUE,
                           showLine=TRUE,
                           enableScrollWheel=TRUE,
                           mapType='terrain',
                           useMapTypeControl=TRUE))
        }
    }) #renderGvis

    output$otemp <- renderPrint({
      s <- samp()
      mean(s$TEMP)
      })

  } # function
) #server
